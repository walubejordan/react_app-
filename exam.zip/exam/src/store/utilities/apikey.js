exports.config = {
  API_KEY: "AIzaSyDKscmfqF_tqvOmBYaDYpLb6TZtjwHrcR4",
};
